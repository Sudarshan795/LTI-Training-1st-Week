package com.lti.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Product;
import com.lti.service.ProductRepositoryImpl;
import com.lti.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/smartshop")
public class ProductController {
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	ProductRepositoryImpl productRepositoryImpl;

	@PostMapping("/addproduct")
	public Product addProduct(@RequestBody Product product) {
		logger.info("addProduct method of ProductController");
		return productRepositoryImpl.addProduct(product);
	}
	@GetMapping("/getproductbyid/{id}")
	public Product getProductById(@PathVariable long id){
		logger.info("getProduct method of ProductController");
		return productRepositoryImpl.getProduct(id);
	}
	@PutMapping("/updateproduct")
	public Product updateProduct(@RequestBody Product product) throws ResourceNotFoundException {
		logger.info("UpdateProduct method of ProductController");
		return productRepositoryImpl.updateProduct(product);
	}
	@GetMapping("/getstock")
	public List<Product> getstock(){
		logger.info("getStock method of ProductController");
		return productRepositoryImpl.getstock();
	}
	@GetMapping("/getstockbyproductname/{pname}")
	public List<Product> getstockByProductName(@PathVariable String pname){
		logger.info("getstockByProductName method of ProductController");
		return productRepositoryImpl.getstockByProductName(pname);
	}
	@GetMapping("/getstockbycategoryname/{category}")
	public List<Product> getstockByCategoryName(@PathVariable String category){
		logger.info("getstockByCategoryName method of ProductController");
		return productRepositoryImpl.getstockByCategoryName(category);
	}
	@DeleteMapping("/delete")
	public String deleteLessRated() {
		logger.info("Delete method of ProductController");
		return productRepositoryImpl.deleteLessRated();
	}
	@PutMapping("/totalprice")
	public String calTotalPrice() {
		logger.info("Calculate TotalPrice method of ProductController");
		return productRepositoryImpl.calTotalPrice();
	}
	
	
}