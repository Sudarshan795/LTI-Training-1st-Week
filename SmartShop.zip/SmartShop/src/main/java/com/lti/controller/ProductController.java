package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Product;
import com.lti.service.ProductRepositoryImpl;
import com.lti.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/smartshop")
public class ProductController {

	@Autowired
	ProductRepositoryImpl productRepositoryImpl;

	@PostMapping("/save")
	public Product CreateProduct(@RequestBody Product product) {
		return productRepositoryImpl.CreateProduct(product);
	}

	@DeleteMapping("/removeproduct")
	public String RemoveProduct() throws ResourceNotFoundException{

		productRepositoryImpl.RemoveProduct();
		return "Successful";
	} 
	
	@GetMapping("/SearchProduct")
	public List<Product> SearchAllProduct() throws ResourceNotFoundException {
		return productRepositoryImpl.getAllProduct();
	}
	
	
}