package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "name", nullable = false)
	private String name;
	@Column(name = "category", nullable = false)
	private String category;
	@Column(name = "qty", nullable = false)
	private int qty;
	@Column(name = "unit_price", nullable = false)
	private int unitPrice;
	@Column(name = "total_price", nullable = false)
	private int totalPrice;
	@Column(name = "rating", nullable = false)
	private int rating;

	public Product(long id, String name, String category, int qty, int unitPrice, int totalPrice, int rating) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.qty = qty;
		this.unitPrice = unitPrice;
		this.totalPrice = totalPrice;
		this.rating = rating;

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", qty=" + qty + ", unitPrice="
				+ unitPrice + ", totalPrice=" + totalPrice + ", rating=" + rating + "]";
	}

}
