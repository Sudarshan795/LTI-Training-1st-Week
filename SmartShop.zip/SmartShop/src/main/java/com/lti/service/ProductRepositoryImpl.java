package com.lti.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.lti.dao.ProductRepository;
import com.lti.exception.ResourceNotFoundException;
import com.lti.model.Product;

@Service
public class ProductRepositoryImpl {

	@Autowired
	ProductRepository productRepository;
	
	//Add Product
	public Product addProduct(@RequestBody Product product) {
		return productRepository.save(product);
	}
	
	//Get Product By ID
	public Product getProduct(long productid) {
		return productRepository.getById(productid);
	}

	//Update Product
	public Product updateProduct(Product product) throws ResourceNotFoundException {
		Product prod = productRepository.findById(product.getId()).orElseThrow(
				() -> new ResourceNotFoundException("product not found for this Productid :: " + product.getId()));
		if (product.getName() != null)
			prod.setName(product.getName());
		if (product.getCategory() != null)
			prod.setCategory(product.getCategory());
		if (product.getQty() != 0)
			prod.setQty(product.getQty());
		if (product.getRating() != 0)
			prod.setRating(product.getRating());
		if (product.getUnitPrice() != 0)
			prod.setUnitPrice(product.getUnitPrice());
		return productRepository.save(prod);
	}
	//Get Stock
	public List<Product> getstock() {
		return productRepository.findAll();
	}

	//Find Stock by Name
	public List<Product> getstockByProductName(String pname) {
		return productRepository.findAll().stream().filter(p -> p.getName().equals(pname)).toList();
	}
	//Find Stock by Category
	public List<Product> getstockByCategoryName(String category) {
		return productRepository.findAll().stream().filter(p -> p.getCategory().equals(category)).toList();
	}
	
	//Delete Product
	public String deleteLessRated() {
		List<Product> allProducts = productRepository.findAll();
		int counter = 0;
		for (Product p : allProducts) {
			if (p.getRating() < 2) {
				counter++;
				productRepository.deleteById(p.getId());
			}
		}
		String message = counter + " Product Deleted";
		return message;
	}

	public String calTotalPrice() {
		List<Product> allProducts = productRepository.findAll();
		for (Product p : allProducts) {
			p.setTotalPrice(p.getQty() * p.getUnitPrice());
			productRepository.save(p);
		}
		String message = allProducts.size() + " Product Updated";
		return message;
	}

}
