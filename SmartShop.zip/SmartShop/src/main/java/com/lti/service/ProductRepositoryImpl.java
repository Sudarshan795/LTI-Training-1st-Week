package com.lti.service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lti.dao.ProductRepository;
import com.lti.exception.ResourceNotFoundException;
import com.lti.model.Product;

@Service
@Component
public class ProductRepositoryImpl {

	@Autowired
	ProductRepository productRepository;
	
	//Search all products
	public List<Product> getAllProduct()  {
	     List<Product>productList=productRepository.findAll();
			try {
				if(productList.isEmpty()!=true) 
					return productList;
					else
						throw new ResourceNotFoundException("Product Not Founds");
	         } catch (Exception e) {
		
	            }
			return null;
		}

	//Create product or update
	public Product CreateProduct(Product product) {
		return productRepository.save(product);
	}
	//Search product according to name
	public List<Product> searchList() {
		return productRepository.sortBynameList();

	}
	
	//Delete the product under rating 2
	public void RemoveProduct() {
		List<Product> prod=productRepository.findAll();
		List<Product> filteredlist=prod.stream().filter(p->p.getRating()<2).collect(Collectors.toList());
		for(Product p: filteredlist) {
			productRepository.delete(p);
		}
	}
	
	
	//Total price calcute total price = qty*unitprice
	public void TotalPrice() {
		List<Product> prod=productRepository.findAll();
		for(Product p: prod) {
			long totalPrice= p.getQty()*p.getUnitPrice();
				productRepository.totalPrice(totalPrice);
			
		}
	}
}