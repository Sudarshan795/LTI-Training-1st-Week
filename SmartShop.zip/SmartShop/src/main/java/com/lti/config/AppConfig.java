package com.lti.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.lti.service.ProductRepositoryImpl;

@Configuration
public class AppConfig {
	
	/*@Bean
	public ProductRepositoryImpl productRepositoryImpl(){
		return new ProductRepositoryImpl();*/
	}

