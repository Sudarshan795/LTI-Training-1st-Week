package com.lti.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.lti.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{
	
	/*
	 * @Query(value = "select c from Product c ORDER BY name") List<Product>
	 * sortBynameList();
	 * 
	 * 
	 * @Modifying
	 * //@Query(value="update Product p SET p.total_price=(p.unit_price*p.qty)")
	 * void totalPrice( long l);
	 * 
	 * @Query(value = "select c from Product c") Optional<Product>
	 * findAll(List<Product> products);
	 */

}
